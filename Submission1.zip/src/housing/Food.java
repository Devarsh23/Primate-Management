package housing;

/**
 * This is the enum class which contains the choices of favourite food of monkey.
 * it includes Seeds, fruits, insects, egg, leaves, nuts, and treesap.
 */
public enum Food {
  Seeds, Fruits, Insects, Egg, Leaves, Nuts, TreeSap
}