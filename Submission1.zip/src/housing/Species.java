package housing;

/**
 * This is the enum class which contains the species of monkey.
 * it includes DRILL, GUEREZA, HOWLER, MANGABEY, SAKI, SPIDER, SQUIRREL, and TAMARIN.
 */
public enum Species {
  DRILL, GUEREZA, HOWLER, MANGABEY, SAKI, SPIDER, SQUIRREL, TAMARIN
}
