package housing;

/**
 * This is the enum class which contains the Sex of monkey.
 * it includes Male and Female.
 */
public enum Sex {
  MALE, FEMALE
}