package housing;

/**
 * This is the enum class which contains the size of monkey.
 * it includes small, medium, and large.
 */
public enum Size {
  SMALL, MEDIUM, LARGE;
}
